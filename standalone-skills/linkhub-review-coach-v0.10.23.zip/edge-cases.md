# Review edge cases

## Lifecycle and authorization

- IN_REVIEW discovery starts from `reviews_listMyClusterTargets`, never from membership teams. `not_cluster_leader` means there is no configured cluster to infer: say so and stop unless the user supplied an exact report URL that passes the assigned-reviewer/company-admin authorization fallback.
- More than one returned cluster leader assignment is not guessed away. Show the returned cluster names and ask the user which cluster to review.
- A truncated cluster target response is incomplete and cannot be used to select a team or person.
- `DRAFT`: stop and route report completion to `linkhub-report-coach`.
- `IN_REVIEW`: normal review workflow.
- `CLOSED_*`: review content is read-only and cannot reopen, including for admins. An assigned validator or admin may separately approve/reject the bonus through the personal bonus-validation flow, with motivation and exact-proposal confirmation.
- Caller is neither assigned reviewer nor company admin: stop. Never substitute another user ID.
- Archived team: historical reads remain valid. Weight and Next writes must not mutate active KR state; adding a new KR is not allowed.

## Snapshot completeness

- An Analyze preview with `completeness.paginationRequired: true` must be completed through `reviews_getAnalyzePage` and `reviews_getAnalyzeText` as described in the skill. It does not require a manual inventory or abandoning Analyze. Other `potentiallyTruncated: true` contexts, or a failed continuation, remain incomplete: do not save dependent changes or confirm closure from them.
- Missing `resultNext` for a positive-weight tracked result: report the exact KR and stop before closure.
- Untracked active KR: explain that it is outside the submitted report snapshot. If the reviewer wants it to govern the next period, apply the requested `reviews_attachKeyResult` directly; it enters at zero, then requires a valid user-chosen complete rebalance. Do not use reporter-side result creation.
- KR that does not exist yet: search indicators first, create what is missing, then `reviews_savePendingKeyResult`. It is created only at closure; if the review is not closed it stays pending and can be cancelled. Never say the tool is missing.
- Removed or missing KR with positive proposed weight: stop. A historical snapshot may be set to zero, but an active replacement requires a deliberate product decision.

## Weights

- Verify next-period team ownership before discussing relative priority. Work transferred outside the team should normally receive zero, with a forward-looking ownership rationale; do not mislabel it as poor performance or mere stabilization.
- Send every active tracked result once in `reviews_rebalanceWeights`, including unchanged rows.
- Weights must be finite, between 0 and 100, multiples of 5, and total exactly 100.
- Validate those constraints before showing the proposal, not only before the write. Report an inherited non-multiple accurately as current state, but never repeat it as a proposed value.
- Every changed weight needs a non-empty, forward-looking rationale tied to priority before the next report, not merely to the observed result in the closed period.
- Duplicate positive-weight indicators are invalid. Do not work around the backend by splitting calls.
- A zero weight automatically marks its Next result as removed. Highlight this in the one proposal or verified outcome.

## Evidence and dates

- `cannotMeasureAt` means the report did not establish a measurable actual; zero-valued storage fields are not evidence of zero performance.
- Auto-submitted notes describe system behavior, not the reporter's judgment.
- Compare `finishedAt` and note dates with `trackingDate`. Label later work as post-period follow-up.
- Past results and risks inform the interview, but `weightReviewed` governs the active KR allocation for the next operating period; never describe it as rewriting the closed period.
- An empty evidence response is unavailable evidence, never zero.

## Highest-risk coverage

- Every positive-weight KR must retain at least one active `highest` risk before Next validation.
- Coverage is a minimum, not an exclusivity rule: keep any number of `highest` risks on the same KR.
- New review risks always start at `highest`, including when the KR already has one or more `highest` risks. Apply the creation request directly; never ask for the priority or reconfirmation.
- Creating, promoting, or selecting a `highest` risk never demotes the other risks. An omitted reference keeps its priority; only an explicit user-chosen change to that risk may lower it.
- A proposal that demotes the last `highest` risk of a KR is incomplete until another existing risk is promoted or a new `highest` risk is explicitly chosen for that KR.
- Zero-weight KRs are excluded from this coverage requirement because they are outside the active next-period allocation.

## Empty and incomplete reports

- A genuinely empty report may close only as `BELOW_EXPECTATIONS`, after the user explicitly acknowledges that no KR was reviewed.
- Any non-empty review with unreviewed weights, missing reviewed forecast/target, or total other than 100 must not close.
- A zero-weight KR is complete without Next validation; every positive-weight KR requires both reviewed Next values.

## Closure

- Call `reviews_getCloseContext` again after any later write.
- A close-context approval is not authorization to close. Neither is an earlier “procediamo”, a stated preferred outcome, a request to draft the note, or approval of another write group.
- Show the exact final note, translated outcome label, and all user-visible closure effects first. Only an unambiguous affirmative answer to the dedicated question asked after that preview authorizes `reviews_close`.
- If the mentee evaluation context is present, require both explicit integer 1–5 star scores even with 0 risks or initiatives. If absent, omit the evaluation. Never invent evidence or derive scores from legacy career trends.
- Use either reviewer text notes or a valid Loom share URL as appropriate; never invent or normalize a video URL yourself.
