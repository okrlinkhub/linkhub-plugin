# LinkHub MCP review tools

## Primary review tools

| Tool | Purpose |
| --- | --- |
| `reviews_listMyClusterTargets` | Resolve the current user's cluster through the team configured as `teamClusterLeaderId`, then return only that cluster's active teams, people, and assigned pending reviews; returns `not_cluster_leader` instead of falling back to membership teams |
| `reviews_getContext { reportId? \| reportSlug? }` | Complete reviewer snapshot, team leader, notes, KR/indicator details including each indicator's latest value and date, previous reports, untracked KRs, and readiness |
| `reviews_getAnalyzeContext` | Bounded preview; when completeness.paginationRequired is true, finish the inventory with getAnalyzePage |
| `reviews_getAnalyzePage { reportId, kind, keyResultId?, riskId?, paginationOpts }` | Page positive-weight keyResults, risks per KR, or initiatives per team/KR/risk. Use numItems 1–10, null first cursor, then continueCursor until isDone, including empty pages. |
| `reviews_getAnalyzeText { reportId, riskId?, initiativeId?, field, offset }` | Exactly one element; description or initiative notes in chunks of 1000 characters. Follow nextOffset until isDone. |
| `reviews_rebalanceRiskPriorities { reportId, changes[] }` | Atomic priority update for the user-chosen risk group; rejects a final state that leaves any positive-weight KR without a `highest` risk |
| `reviews_rebalanceWeights { reportId, allocations[], pendingAllocations? }` | Atomic complete user-chosen 100% weight rebalance, pending KRs included; changed rows require reviewer notes |
| `reviews_attachKeyResult { reportId, keyResultId, reviewerNotes }` | Attach an existing untracked active KR at zero, before the complete user-chosen rebalance |
| `reviews_savePendingKeyResult { reportId, pendingKeyResultId?, objectiveId, indicatorId, weight, forecastValue, targetValue, reviewerNotes }` | Propose a new KR during the review. It is not created in the team yet; it counts in the next-period 100% and is created when `reviews_close` succeeds. Listed in `reviews_getContext.pendingKeyResults` |
| `reviews_cancelPendingKeyResult { pendingKeyResultId }` | Cancel a pending KR; it is never created |
| `reviews_updateNextResult { resultNextId, forecastValueReviewed, targetValueReviewed, notes? }` | Reviewer-only Next validation with audit; preserves reported values |
| `reviews_getCloseContext { reportId }` | Final completeness, recommendation, mentee and report-period evidence when the reviewer is also mentor |
| `reviews_getEvaluationEvidence { reportId, kind, paginationOpts }` | Page all created risks/initiatives or resolved risks/completed initiatives in the report period. Follow continueCursor until isDone. |
| `reviews_close { reportId, resultType, reviewerNotes?, videoReviewUrl?, menteeEvaluation? }` | IN_REVIEW → CLOSED_* after dedicated confirmation |

`allocations[]` items are `{ resultTrackedId, weightReviewed, reviewerNotes? }`. Include every active tracked result exactly once. Changed weights require `reviewerNotes`; unchanged weights may preserve existing reviewer notes by omitting the field. `trackedResults[].reporterNotes` and `trackedResults[].reviewerNotes` have distinct authors and must never be merged or copied into each other.

The Next tool keeps technical field names for transport, but the interview must always present them as `obiettivo minimo` and `obiettivo massimo`. Base the proposal on `keyResults[].indicator.latestValue` when present, even if the reviewed-period result is marked unmeasurable.
For a positive-weight KR, `forecastValueReviewed` and `targetValueReviewed` must be finite, different values forming a success interval in the indicator's direction. A neutral, not-yet-measurable increasing KR defaults to `0 / 10`, never `0 / 0`. The tool rejects equal values; collect valid corrected values and apply them without reconfirmation.
If a zero-weight KR was marked `0 / 0` for removal or was newly attached with placeholder `0 / 0`, use `reviews_updateNextResult` to save the user-chosen valid interval before giving it positive weight. The tool can correct the interval while the weight is zero; it does not restore the weight itself.

## Reused read tools

| Tool | Purpose |
| --- | --- |
| `mcp_membershipProfile` | Current MCP identity and company |
| `indicators_getExplanation` / `indicators_queryEvidence` | Mandatory definition plus bounded ClickHouse evidence before proposing Next values for every automated positive-weight KR; reuse results within the review |
| `milestones_listByIndicator` | Tool-returned milestone values and totals |

`teams_listMineByCompany` is not a review-cluster discovery tool: it returns membership, directly led, or admin-visible teams and must not be used to infer the cluster leader team.

## Indicator and Objective discovery or creation

| Tool | Purpose |
| --- | --- |
| `indicators_search { query }` | Company manual and automated indicators by description or slug |
| `indicators_listExplainable` | Company automated indicators |
| `indicators_resolve { reference }` | Exact ID, slug or link |
| `indicators_create` / `indicators_update` | Manual indicator for a new KR |
| `objectives_byTeam` / `objectives_create` | Objective of the reviewed team |

`pendingAllocations[]` items are `{ pendingKeyResultId, weight }`; when present, list every pending KR. Never call `keyResults_create` on a team in review.

## Milestone writes

| Tool | Purpose |
| --- | --- |
| `milestones_create` | Create with description, percentage `value`, optional `forecastDateIso` |
| `milestones_update` | Update description, percentage weight or deadline; `forecastDateIso: null` removes the deadline |
| `milestones_complete` | Complete on explicit `achievedAtIso` |
| `milestones_reopen` | Clear an incorrect completion |
| `milestones_remove` | Soft-delete immediately on an explicit user request |
| `milestones_requestChange` / `milestones_listChangeRequests` | Completion-project indicators without reviewer rights: request the change, then read its status |

Read before writing, apply complete requests directly, then reread
`milestones_listByIndicator`. Preserve the reporter's historical tracked result.
These tools retain MCP permission checks: the indicator assignee or a company/
global admin may manage its milestones. Reviewer status alone does not grant
this permission. Timed sessions also restrict the indicator to the fixed team.

## Reused writes during Analyze

Use `risks_create`, `risks_update`, `risks_move`, `risks_remove`, `initiatives_create`, `initiatives_update`, `initiatives_checkIn`, `initiatives_finish`, or `initiatives_remove` directly after the user’s request or first choice of proposed values, without another confirmation. Every review `risks_create` call supplies `priority: "highest"`; never ask for its priority. `risks_move` accepts `riskId` and `targetKeyResultId` for an active target KR in the same team and preserves the risk and linked initiatives. Prefer `reviews_rebalanceRiskPriorities` over several `risks_update` calls for a group of explicitly requested priority changes. Include only those changes, never inferred demotions of unselected risks. The coverage check requires at least one `highest` per positive-weight KR and permits multiple `highest` risks on the same KR.

`initiatives_create` requires one active `riskId`. A reviewer-created initiative must name the selected stable risk reference in the readable proposal and explain how it mitigates that risk; never offer an unlinked initiative. If no suitable risk exists, create the user-chosen risk first without reconfirmation. Reviewer-created initiatives default to the `reviews_getContext.teamLeader` assignee and a 7-day check-in. Ask whether to include the standard assignment message; do not spend separate interview turns reconfirming those defaults.

When reviewing in an isolated sandbox, invoke the indicator evidence functions through that sandbox as well. Never switch to a production-connected MCP. A failed evidence operation is not retried with speculative parameters or a different environment.

`reviewerNotes` is a short business message to the reporter, not an audit log. Exclude assignee defaults, check-in dates, assignment-message status, internal IDs, payload details, and evidence-tool diagnostics.

## Do not use during review

- `reports_getAnalyzeContext`: reporter-oriented, one-KR-at-a-time Analyze context; use the reviewer tools with their reviewer authorization instead.
- `keyResults_rebalanceWeightInDraftReport`: reporter DRAFT semantics.
- `resultTracked_upsert`, `resultTracked_markUnmeasurable`, `resultTracked_markCompleted`: reporter evaluation semantics.
- `resultNext_upsert`, `resultNext_skipWithDefaults`: overwrite or create reporter-side Next data.
- `reports_submit`: DRAFT submission, not review closure.


## Bonus validation tools (assigned validator, including non-admin)

| Tool | Purpose |
| --- | --- |
| `bonusValidations_list { scope?, validationStatus?, validatorId?, teamId?, reporterId?, reviewerId?, trackingDate?, paginationOpts }` | Defaults to own assigned green reports awaiting validation. `validationStatus` is `IN_PROGRESS`, `IS_VALID`, `NOT_VALID` or `ALL` (all three states). Only admins may use `scope: "company"` or another validator. Each page contains up to 5 candidate reports; follow `continueCursor` until `isDone`, including empty pages. Includes report ID/slug/URL, team, people, tracking date, validation notes/author/time and informational caution signals. |
| `bonusValidations_submit { reportId, validationStatus, motivation, confirmed? }` | Assigned validator or admin saves `IS_VALID` / `NOT_VALID` with mandatory nonblank motivation (maximum 3000 characters) and `confirmed: true` after exact-proposal confirmation. Shares the web UI's transaction: validation audit fields and linked `actualBonus`; does not change achievement or reopen review. |

Start from the personal Review queue, never admin-only discovery or team fan-out.
The annual history covers January 1 through the selected report's tracking date.
Previous-period results use the latest earlier closed report of the same team;
the previous-month interval uses the latest closed report in the previous calendar
month and the same KR/indicator. Historical milestone snapshots are used instead
of current milestones. The reviewer comparison covers each currently active team
led by that reviewer in the same company at the exact tracking date; absent or
ambiguous matches remain unknown. Current indicator configuration determines
automation and improvement direction. Positive-weight KRs expose their result,
score and effective reviewed/reported weight; no automatic validation follows.
`suggestedNextIntervalsPresent` identifies recorded original suggestion provenance,
not proof of the reviewer's final use of defaults. `suggestedDefaultsUsed` is null
with a reason where that choice was never recorded. Read limits (100 period
reports, 50 results per report, 10 reviewer-led teams) return unknown signals with
reasons on saturation. No unknown total is presented as a complete count.
